//816005989
import java.util.ArrayList;

public class ChatBotPlatform
{
    // Variables
    ArrayList<ChatBot> bots;
    private String str1; //Used to Format ChatBoxList
    private String str2; //Used to Format ChatBoxList
    private int arrayListSize;
    
    // Constructor
    public ChatBotPlatform()
    {
       bots = new ArrayList<ChatBot>();
    }
    
    // Accessors
    public boolean addChatBot(int LLCcode){
        if(ChatBot.limitReached() == true){
            return false;
        }else{
            ChatBot bot = new ChatBot(LLCcode);
            bots.add(bot);
            return true;
        }
    }

    public String getChatBotList(){
        int i = 0;
        str1 = "";
        System.out.println("--------------------");
        System.out.println("Your ChatBots");
        for(ChatBot cb : bots){
            str2 = "Bot Number: " + i + " " + cb.toString();
            str1 = str1.concat(str2) + "\n";
            i++;
        }
        return str1 + "Total Messages Used: " + ChatBot.getTotalNumResponsesGenerated() + "\n" + "Total Messages Remaining: " + ChatBot.getTotalNumMessagesRemaining() + "\n" + "--------------------";
    }
    
    public String interactWithBot(int botNumber, String message){
        arrayListSize = bots.size();
        if(botNumber > arrayListSize){
            return "Incorrect Bot Number (" + botNumber + ") Selected. Try again";
        }
        return bots.get(botNumber).prompt(message);
    }
}
