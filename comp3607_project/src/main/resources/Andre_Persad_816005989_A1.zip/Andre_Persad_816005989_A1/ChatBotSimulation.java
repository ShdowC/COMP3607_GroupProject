//816005989
public class ChatBotSimulation
{
    public static void main(String[] args){
        System.out.println("Hello World");
        
        ChatBotPlatform cbp1 = new ChatBotPlatform();
        cbp1.addChatBot(1);
        cbp1.addChatBot(2);
        cbp1.addChatBot(3);
        cbp1.addChatBot(4);
        cbp1.addChatBot(5);
        cbp1.addChatBot(6);
        cbp1.addChatBot(7);
        cbp1.addChatBot(8);
        
        System.out.println(cbp1.getChatBotList());
        
        System.out.println(cbp1.interactWithBot(0   , "Can you tell me what is Java?"));
        System.out.println(cbp1.interactWithBot(1   , "How do you set up an IDE?"));
        System.out.println(cbp1.interactWithBot(0   , "Is it possible to make a chatbot"));
        System.out.println(cbp1.interactWithBot(4   , "Can you help me with troubleshooting a technical issue?"));
        System.out.println(cbp1.interactWithBot(5   , "Can you explain the underlying algorithms that power your decision-making process?"));
        System.out.println(cbp1.interactWithBot(1   , "How frequently are you updated or improved?"));
        System.out.println(cbp1.interactWithBot(1   , "Are there any plans for incorporating natural language understanding improvements?"));
        System.out.println(cbp1.interactWithBot(1   , "Can you explain the underlying algorithms that power your decision-making process?"));
        System.out.println(cbp1.interactWithBot(5   , "What programming languages were used to develop you?"));
        System.out.println(cbp1.interactWithBot(5   , "How does your artificial intelligence system work?"));
        System.out.println(cbp1.interactWithBot(0   , "Are there any specific industries or applications where your AI excels?"));
        System.out.println(cbp1.interactWithBot(2   , "How do you handle ambiguous or uncertain situations?"));
        System.out.println(cbp1.interactWithBot(4   , "Can you share examples of successful applications or use cases where you've been particularly effective?"));
        System.out.println(cbp1.interactWithBot(7   , "What ethical considerations are taken into account in your development?"));
        System.out.println(cbp1.interactWithBot(3   , "Can you describe the limitations of your current capabilities?"));
        
        System.out.println(cbp1.getChatBotList());
    }
}
